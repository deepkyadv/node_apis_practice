const express = require("express");
const user = require("./src/routes/user");
const cors = require("cors");

const { default: mongoose } = require("mongoose");
const app = express();

app.use(
  cors({
    origin: "*", 
    methods: ["GET", "POST"],
    credentials: true,
  })
);

const mongoUrl = 
  "mongodb+srv://harendratemp18:SUwUAsrnCDkarwYN@test.a5gp1.mongodb.net/?retryWrites=true&w=majority&appName=Test";

app.get("/get-data", (req, res) => {
  res.status(200).json({ message: "this is test api" });
});

app.use(express.json());
app.use("/api", user);

mongoose
  .connect(mongoUrl)
  .then(() => console.log("DBConnection Successfull!!!"))
  .catch((err) => {
    console.log(err);
  });

app.listen(8000, () => {
  console.log("Server started on port 8000...");
});
